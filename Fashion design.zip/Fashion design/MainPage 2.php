<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="main_style.css">


	<!--  Bootstrap -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


	<title>Dashboard</title>

	<!-- JQUERY SCRIPT -->

	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

	<!-- Javascropt -->

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>



</head>
<body >


<nav class="navbar fixed-top navbar-expand-lg navbar-warning bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar scroll</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="MainPage.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="MainPage 2.php">Designs</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarScrollingDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Link
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
            <li><a class="dropdown-item" href="#">Link</a></li>
            <li><a class="dropdown-item" href="#">kurti</a></li>
            <li><a class="dropdown-item" href="#">Pamjabi</a></li>
            <li><a class="dropdown-item" href="#">Shirt</a></li>
            <li><a class="dropdown-item" href="#">Pant</a></li>
            <li><a class="dropdown-item" href="#">Suit</a></li>
            <li><a class="dropdown-item" href="#">Salwar</a></li>
            <li><a class="dropdown-item" href="#">Sharee</a></li>
            <li><a class="dropdown-item" href="#">Western</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="Login.php" tabindex="-1" aria-disabled="false">LogOut</a>
        </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>


<br><br>

	<!-- CODE ENDS -->




<!-- Shirt -->


		<div class="ImageDiv">	
	
		


		<div class="container py-5">
			<h2>Shirt :</h2>

			<form method="post" action="See_Product_Catagory.php">
				
					<input type="submit" name="Catagory" value="Shirt" class="btn btn-success">

			</form>
			


			<div class="row mt-4">
				
				
	<?php
		$servername = "localhost"; 
		$username = "root"; 
		$password = "";
		$dbname = "fashiondream"; 
		// Create connection 
		$conn = mysqli_connect($servername, $username, $password, $dbname); 
 		if (!$conn) 
		{ 
			die("Connection failed: " . mysqli_connect_error()); 
		} 
		else
		{
			//echo "Succesfully connected";
		}
	?>
		
		<?php 

			$sql = "SELECT * FROM fashion_images where image_type='Shirt' limit 4";
		   $result = mysqli_query($conn, $sql); 

	 	if (mysqli_num_rows($result) > 0) 
	     	{
		    	while ($images = mysqli_fetch_assoc($result)) {
			

			?>


			<div class="col-md-3 mt-3">
				
				<div class="card">

				<img width="255" height="200" src="uploads/<?=$images['image_url']?>">

					<div class="card-body">
					
					  <h4 class="card-title"><?php echo $images['Name']; ?> </h4>
					  <h4 class="card-title"><?php echo $images['Price']; ?> </h4>
					  <p class="card-title"><?php echo $images['Description']; ?></p>
					  <p class="card-title"><?php echo $images['image_type']; ?></p>
					  <form action="See Product Info.php" method="post">
					
						<input type="hidden" name="edit_id" value="
							<?php
								echo $images['id'];
						?>">
						<button type="submit" class="btn btn-success" name="edit_btn">Select
						</button>

					</form>

					</form>

					</div>

				</div>

			</div>

		<?php } } ?>

			</div>

		</div>


	</div>







<!-- Kurti -->


<div class="ImageDiv">

		<div class="container py-5">
				<h2>Kurti  :</h2>
			
			<form method="post" action="See_Product_Catagory.php">
				
					<input type="submit" name="Catagory" value="Kurti" class="btn btn-success">

			</form>	
			<div class="row mt-4">
				
				
	<?php
		$servername = "localhost"; 
		$username = "root"; 
		$password = "";
		$dbname = "fashiondream"; 
		// Create connection 
		$conn = mysqli_connect($servername, $username, $password, $dbname); 
 		if (!$conn) 
		{ 
			die("Connection failed: " . mysqli_connect_error()); 
		} 
		else
		{
			//echo "Succesfully connected";
		}
	?>
		
		<?php 

			$sql = "SELECT * FROM fashion_images where image_type='Kurti' limit 4";
		   $result = mysqli_query($conn, $sql); 

	 	if (mysqli_num_rows($result) > 0) 
	     	{
		    	while ($images = mysqli_fetch_assoc($result)) {
			

			?>


			<div class="col-md-3 mt-3">
				
				<div class="card">

				<img width="255" height="200" src="uploads/<?=$images['image_url']?>">

					<div class="card-body">
					
					  <h4 class="card-title"><?php echo $images['Name']; ?> </h4>
					  <h4 class="card-title"><?php echo $images['Price']; ?> </h4>
					  <p class="card-title"><?php echo $images['Description']; ?></p>
					  <p class="card-title"><?php echo $images['image_type']; ?></p>
					  <form action="See Product Info.php" method="post">
					
						<input type="hidden" name="edit_id" value="
							<?php
								echo $images['id'];
						?>">
						<button type="submit" class="btn btn-success" name="edit_btn">Select
						</button>

					</form>

					</form>

					</div>

				</div>

			</div>

		<?php } } ?>

			</div>

		</div>


	</div>





<!-- Salwar -->



<div class="ImageDiv">


		<div class="container py-5">
				<input type="submit" name="Shirt_submit" value="Show More" class="btn btn-success">				
			<div class="row mt-4">
				
				
	<?php
		$servername = "localhost"; 
		$username = "root"; 
		$password = "";
		$dbname = "fashiondream"; 
		// Create connection 
		$conn = mysqli_connect($servername, $username, $password, $dbname); 
 		if (!$conn) 
		{ 
			die("Connection failed: " . mysqli_connect_error()); 
		} 
		else
		{
			//echo "Succesfully connected";
		}
	?>
		
		<?php 

			$sql = "SELECT * FROM fashion_images where image_type='Salwar' limit 4";
		   $result = mysqli_query($conn, $sql); 

	 	if (mysqli_num_rows($result) > 0) 
	     	{
		    	while ($images = mysqli_fetch_assoc($result)) {
			

			?>


			<div class="col-md-3 mt-3">
				
				<div class="card">

				<img width="255" height="200" src="uploads/<?=$images['image_url']?>">

					<div class="card-body">
					
					  <h4 class="card-title"><?php echo $images['Name']; ?> </h4>
					  <h4 class="card-title"><?php echo $images['Price']; ?> </h4>
					  <p class="card-title"><?php echo $images['Description']; ?></p>
					  <p class="card-title"><?php echo $images['image_type']; ?></p>
					  <form action="See Product Info.php" method="post">
					
						<input type="hidden" name="edit_id" value="
							<?php
								echo $images['id'];
						?>">
						<button type="submit" class="btn btn-success" name="edit_btn">Select
						</button>

					</form>

					</form>

					</div>

				</div>

			</div>

		<?php } } ?>

			</div>

		</div>


	</div>


<!-- Western -->



<div class="ImageDiv">


		<div class="container py-5">
				<input type="submit" name="Shirt_submit" value="Show More" class="btn btn-success">				
			<div class="row mt-4">
				
				
	<?php
		$servername = "localhost"; 
		$username = "root"; 
		$password = "";
		$dbname = "fashiondream"; 
		// Create connection 
		$conn = mysqli_connect($servername, $username, $password, $dbname); 
 		if (!$conn) 
		{ 
			die("Connection failed: " . mysqli_connect_error()); 
		} 
		else
		{
			//echo "Succesfully connected";
		}
	?>
		
		<?php 

			$sql = "SELECT * FROM fashion_images where image_type='Western' limit 4" ;
		   $result = mysqli_query($conn, $sql); 

	 	if (mysqli_num_rows($result) > 0) 
	     	{
		    	while ($images = mysqli_fetch_assoc($result)) {
			

			?>


			<div class="col-md-3 mt-3">
				
				<div class="card">

				<img width="255" height="200" src="uploads/<?=$images['image_url']?>">

					<div class="card-body">
					
					  <h4 class="card-title"><?php echo $images['Name']; ?> </h4>
					  <h4 class="card-title"><?php echo $images['Price']; ?> </h4>
					  <p class="card-title"><?php echo $images['Description']; ?></p>
					  <p class="card-title"><?php echo $images['image_type']; ?></p>
					  <form action="See Product Info.php" method="post">
					
						<input type="hidden" name="edit_id" value="
							<?php
								echo $images['id'];
						?>">
						<button type="submit" class="btn btn-success" name="edit_btn">Select
						</button>

					</form>

					</form>

					</div>

				</div>

			</div>

		<?php } } ?>

			</div>

		</div>


	</div>


<!-- Panjabi -->



<div class="ImageDiv">


		<div class="container py-5">
				<input type="submit" name="Shirt_submit" value="Show More" class="btn btn-success">				
			<div class="row mt-4">
				
				
	<?php
		$servername = "localhost"; 
		$username = "root"; 
		$password = "";
		$dbname = "fashiondream"; 
		// Create connection 
		$conn = mysqli_connect($servername, $username, $password, $dbname); 
 		if (!$conn) 
		{ 
			die("Connection failed: " . mysqli_connect_error()); 
		} 
		else
		{
			//echo "Succesfully connected";
		}
	?>
		
		<?php 
			$c=0;
			$sql = "SELECT * FROM fashion_images where image_type='Panjabi' limit 4";
		   $result = mysqli_query($conn, $sql); 

	 	if (mysqli_num_rows($result) > 0) 
	     	{	
	     	
		    	while ($images = mysqli_fetch_assoc($result)) {

			?>


			<div class="col-md-3 mt-3">
				
				<div class="card">

				<img width="255" height="200" src="uploads/<?=$images['image_url']?>">

					<div class="card-body">
					
					  <h4 class="card-title"><?php echo $images['Name']; ?> </h4>
					  <h4 class="card-title"><?php echo $images['Price']; ?> </h4>
					  <p class="card-title"><?php echo $images['Description']; ?></p>
					  <p class="card-title"><?php echo $images['image_type']; ?></p>
					  <form action="See Product Info.php" method="post">
					
						<input type="hidden" name="edit_id" value="
							<?php
								echo $images['id'];
						?>">
						<button type="submit" class="btn btn-success" name="edit_btn">Select
						</button>

					</form>

					</form>

					</div>

				</div>

			</div>

		<?php } } ?>

			</div>

		</div>


	</div>






</body>
</html>