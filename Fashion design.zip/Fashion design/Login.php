<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="Login_style.css">
	<title>Login Page</title>
</head>
<body class="body">

    <form method="post">
	   <div class="MainBox">
	

		<div class="SideBox">
			
			<img src="SideBox.jpg" width="300px" height="400px" class="SideBox_Img">
		</div>

		<div class="RegBox">
			
			<p class="RegPera">Register</p>
			
			<input type="text" name="UserName" placeholder="Username" class="input">

			<input type="text" name="NID" placeholder="NID" class="input">
			

			
			<input type="text" name="Email" placeholder="Email Address" class="input">



			<input type="password" name="Password" placeholder="Password" class="input">


			<input type="submit" name="login" value="Login" class="login_btn">

			<input type="submit" name="signup" value="SignUp" class="signup_btn">

			<input type="submit" name="admin_go" value="Goto_Admin" class="signup_btn">

			

		</div>
	  </div>

	</form>


	<?php


        $servername = "localhost"; 
		$username = "root"; 
		$password = "";
		$dbname = "fashiondream"; 
		// Create connection 
		$conn = mysqli_connect($servername, $username, $password, $dbname); 
		// Check connection 
		if (!$conn) 
		{ 
			die("Connection failed: " . mysqli_connect_error()); 
		} 
		else
		{
			echo "Succesfully connected";
		}


		if(isset($_POST['login']))

		{

		$username = $_POST['UserName'];
		$nid = $_POST['NID'];
		$email = $_POST['Email'];
		$password = $_POST['Password'];


	 	$sql = "SELECT * FROM register";
	 	$result = mysqli_query($conn, $sql); 

	 	if (mysqli_num_rows($result) > 0) 
	 	{
	 		while($row = mysqli_fetch_assoc($result)) 
	 		{
	 			$UserNamedb = $row['UserName'];
	 			$NIDdb = $row['NID'];
	 			$Emialdb = $row['Email'];
	 			$Passworddb = $row['Password'];

	 			if(($username==$UserNamedb) &&($nid==$NIDdb) && ($email==$Emialdb) && ($password==$Passworddb))
	 			{
	 				echo "Login successfull";
	 				header('Location:MainPage.php');
	 				break;
	 			}
	 			else
	 			{
	 				echo "Login Fail";
	 				break;
	 			}
	 		}
	 	}

	 	


		}


		if(isset($_POST['signup']))
		{
			header('Location:Register.php');
		}


		if(isset($_POST['admin_go']))
		{
			header('Location:Admin_Panel/Admin.php');
		}

		

	?>



</body>
</html>