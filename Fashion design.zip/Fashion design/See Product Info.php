<!DOCTYPE html>
<html>
<head>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<title></title>

		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</head>


<body>



	<!-- Header Section Ends -->


<nav class="navbar fixed-top navbar-expand-lg navbar-warning bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar scroll</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="MainPage.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="MainPage 2.php">Designs</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarScrollingDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Link
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
            <li><a class="dropdown-item" href="#">Link</a></li>
            <li><a class="dropdown-item" href="#">kurti</a></li>
            <li><a class="dropdown-item" href="#">Pamjabi</a></li>
            <li><a class="dropdown-item" href="#">Shirt</a></li>
            <li><a class="dropdown-item" href="#">Pant</a></li>
            <li><a class="dropdown-item" href="#">Suit</a></li>
            <li><a class="dropdown-item" href="#">Salwar</a></li>
            <li><a class="dropdown-item" href="#">Sharee</a></li>
            <li><a class="dropdown-item" href="#">Western</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="Login.php" tabindex="-1" aria-disabled="false">LogOut</a>
        </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>


<br><br>







	<!-- FILE UPLOAD DATABASE FUNCTION -->
		<?php

			
		?>

		<!-- FILE UPLOAD DATABASE FUNCTION ENDS-->



	<!-- Edit Section Section -->

	<div class="container-fluid">
		
		<!-- database part -->

			<div class="card shadaw mb-4">
				<div class="card-header py-3">
					<h6 class="m-0 font-weight-bold text-primary">Details Info
					</h6>	
				</div>
				<div class="card-body">
					
					<?php 

						$servername = "localhost"; 
						$username = "root"; 
						$password = "";
						$dbname = "fashiondream"; 
						// Create connection 
						$conn = mysqli_connect($servername, $username, $password, $dbname); 
				 		if (!$conn) 
						{ 
							die("Connection failed: " . mysqli_connect_error()); 
						} 
						else
						{
							echo "Succesfully connected";
						}

						$id  = $_POST['edit_id'];

						if(isset($_POST['edit_btn']))
						{

						$sql = "SELECT * FROM fashion_images where id='$id'";
						$result = mysqli_query($conn, $sql); 					


						foreach ($result as $images) {
							
					?>

			<form method="post">
				
					<input type="hidden" name="edit_id" value="<?php echo $images['id']; ?>">
					<div class="form-group">
						<label>Name :</label>
						<input type="text" name="edit_name" class="form-control" placeholder="Image_Name" value="
							<?php 
								echo $images['Name'];
							?>">
					</div>

					<div class="form-group">
						<label>Image_url :</label>
						<input type="text" name="edit_image_url" class="form-control" placeholder="Image_Url" value="
							<?php 
								echo $images['image_url'];
							?>">

					    <img width="255" height="200" src="uploads/<?=$images['image_url']?>">

					<div class="card-body">
					</div>

					<div class="form-group">
						<label>Price :</label>
						<input type="text" name="edit_price" class="form-control" placeholder="Price" value="
							<?php 
								echo $images['Price'];
							?>">
					</div>

					<div class="form-group">
						<label>Description :</label>
						<input type="text" name="edit_description" class="form-control" placeholder="Description" value="
							<?php 
								echo $images['Description'];
							?>">
					</div>
					<br><br>

					<a href="MainPage 2.php" class="btn btn-danger">Cancel</a>
					<button class="btn btn-primary" name="AddToCart"> Add to Cart</button>



			</form>


					<?php

						}
					}

					?>


			<?php 



				if(isset($_POST['AddToCart']))
				{
						
				}



			 ?>


				</div>
			</div>
	</div>










</body>
</html>