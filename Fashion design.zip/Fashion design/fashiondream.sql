-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2022 at 03:50 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fashiondream`
--

-- --------------------------------------------------------

--
-- Table structure for table `fashion_images`
--

CREATE TABLE `fashion_images` (
  `id` int(15) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `image_url` varchar(50) NOT NULL,
  `Price` varchar(15) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `image_type` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fashion_images`
--

INSERT INTO `fashion_images` (`id`, `Name`, `image_url`, `Price`, `Description`, `image_type`) VALUES
(1, 'Shirt_01(Red)				', 'IMG-61f189ebb04e00.52762236.jpg', '7', 'Red check shirt_01', 'Shirt'),
(2, 'Shirt_02', 'IMG-61f18b2d2073f0.33391409.jpg', '800', 'orange and navy check shirt new collection', 'Shirt'),
(7, 'Kurti 01', 'IMG-6204f27fcef632.77828074.jpg', '1200', 'Fashionable pink kurti', 'Kurti'),
(10, 'Shirt 03', 'IMG-620e8f601e6e94.99445051.jpg', '700', 'Red Shirt', 'Shirt'),
(11, 'Shirt 04', 'IMG-620e8f7e8cf811.68674137.jpg', '900', 'Blue Shirt', 'Shirt');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `CustomerId` int(10) NOT NULL,
  `UserName` varchar(15) NOT NULL,
  `NID` varchar(15) NOT NULL,
  `Email` varchar(15) NOT NULL,
  `PhoneNumber` varchar(15) NOT NULL,
  `Address` varchar(15) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `ConfirmPassword` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`CustomerId`, `UserName`, `NID`, `Email`, `PhoneNumber`, `Address`, `Password`, `ConfirmPassword`) VALUES
(2, 'Tareq', '1212', 'tareq@gmail.com', '12312', 'khilgaon', '1310', '1310'),
(3, 'Md Tareq Zaman', '22565', 'tamal777@gmail.', '01866162622', 'khilgaon', 'tamal', 'tamal');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fashion_images`
--
ALTER TABLE `fashion_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`CustomerId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fashion_images`
--
ALTER TABLE `fashion_images`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `CustomerId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
