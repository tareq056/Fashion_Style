<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="Register_style.css">
	<title>Registration Page</title>
</head>
<body class="body">

    <form method="post">
	   <div class="MainBox">
	

		<div class="SideBox">
			
			<img src="SideBox.jpg" width="300px" height="400px" class="SideBox_Img">
		</div>

		<div class="RegBox">
			
			<p class="RegPera">Register</p>
			
			<input type="text" name="UserName" placeholder="Username" class="input">

			<input type="text" name="NID" placeholder="NID" class="input">
			
			<input type="text" name="Email" placeholder="Email Address" class="input">

			<input type="text" name="PhoneNumber" placeholder="Phone Number" class="input">

			<input type="text" name="Address" placeholder=
			"Address" class="input">

			<input type="password" name="Password" placeholder="Password" class="input">

			<input type="password" name="ConfirmPassword" placeholder="Confirm Password" class="input">

			<input type="submit" name="Registerbtn" value="Register" class="Register_btn">

			<input type="submit" name="login" value="GOTO login" class="login">

			

		</div>




		

		
	  </div>
  </form>

<?php


			if(isset($_POST['submit']) && isset($_FILES['my_image']))
			{


				$img_name = $FILES['my_image']['name'];
				$img_size = $FILES['my_image']['size'];
				$tmp_name = $FILES['my_image']['tmp_name'];
				$error = $FILES['my_image']['error'];



				$name = $_POST['Name'];
				$price = $_POST['Price'];
				$description = $_POST['Description'];
				$image_type = $_POST['image_type'];

				echo  $_FILES['my_image']['name'];
				echo "<br>";
				echo $_FILES['my_image']['tmp_name'];
				echo "<br>";
				echo $_FILES['my_image']['size'];
				echo "<br>";
				echo $_FILES['my_image']['error'];
				echo "<br>";


				if($error>=0)
				{
					if($img_size > 170000)
					{
						echo "Size exceed";
					}
					else
					{
						
						$img_ex = pathinfo($_FILES['my_image']['name'],PATHINFO_EXTENSION);
						echo "<br>";
						echo $img_ex;
						$img_ex_lc = strtolower($img_ex);

						$allowed_exs = array("jpg","png","jpeg");

						if(in_array($img_ex_lc, $allowed_exs))
						{
							$new_img_name = uniqid("IMG-",true).'.'.$img_ex_lc;
							$img_upload_path = '../uploads/'.$new_img_name;

							move_uploaded_file($_FILES['my_image']['tmp_name'], $img_upload_path);

							//Insert to Database

							$sql = "INSERT INTO fashion_images(Name,image_url,Price,Description,image_type) VALUES('$name','$new_img_name','$price','$description','$image_type')";

							if (mysqli_query($conn, $sql)) 
							{
								echo "Record saved";
								header('Location:../MainPage.php');
							}
							else
							{
								echo "Error: " . $sql . "<br>" . mysqli_error($conn);
							}
							mysqli_close($conn);


						}
						else
						{
							echo "NOT ALLOWED EXS!!";
						}
					}
				}

			}
			else
			{
				echo "ASDASASADSDSD";
			}


?>




	<?php



   	    $servername = "localhost"; 
		$username = "root"; 
		$password = "";
		$dbname = "fashiondream"; 
		// Create connection 
		$conn = mysqli_connect($servername, $username, $password, $dbname); 
 		if (!$conn) 
		{ 
			die("Connection failed: " . mysqli_connect_error()); 
		} 
		else
		{
			echo "Succesfully connected";
		}



		if(isset($_POST["Registerbtn"]))
		{

			$sql = "INSERT INTO register (UserName,NID,Email,PhoneNumber,Address,Password,ConfirmPassword) VALUES ('$_POST[UserName]', 
				'$_POST[NID]', '$_POST[Email]','$_POST[PhoneNumber]','$_POST[Address]','$_POST[Password]','$_POST[ConfirmPassword]')";


			if((!empty($_POST['UserName'])) || (!empty($_POST['NID'])) || (!empty($_POST['Email'])) || (!empty($_POST['PhoneNumber'])) || (!empty($_POST['Address'])) || (!empty($_POST['Password'])) || (!empty($_POST['ConfirmPassword'])))

			{

				if (mysqli_query($conn, $sql)) 
				{
					echo "Record saved";
					header('Location:MainPage.php');
				}
				else
				{
					echo "Error: " . $sql . "<br>" . mysqli_error($conn);
				}
				mysqli_close($conn);
			}
			else
			{
				echo "Enter all the data!";
			}

			

		}



		if(isset($_POST['login']))
		{
			header('Location:Login.php');
		}
	?>

</body>
</html>